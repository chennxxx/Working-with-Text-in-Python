#!/usr/bin/env python3

import nbformat
import unittest
import spacy

from tmc import points
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'basic_spacy.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}


class ImportSpacy(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['import_spacy']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['import_spacy']]

    @points('p4.1.import_spacy', 'p4.1.import_spacy_x2')
    def test_import_spacy(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if variable exists
            assert 'spacy' in dir()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The module "spacy" was '
                                     f'imported successfully into Python. '
                                     f'2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The module "spacy" was not imported correctly. Did you ' \
                     'spell the module name correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except ModuleNotFoundError:

            # Define error message
            errmsg = 'Python could not find the module "spacy". Did you ' \
                     'spell the module name correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class LoadModel(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Run the previous exercise cell for preliminaries
        exec(nb.cells[exercises['import_spacy']].source)

        # Prepare cell
        prepare_cell(nb.cells[exercises['load_model']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['load_model']]

    @points('p4.2.load_model', 'p4.2.load_model_x2')
    def test_load_model(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if variable exists
            assert 'nlp' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}Variable "nlp" '
                                     f'was defined successfully! 2 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "nlp" was not defined. Remember to store ' \
                     'the language model under the correct variable!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.2.model_type')
    def test_model_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of correct type
            assert isinstance(locals()['nlp'], spacy.lang.en.English)

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The language model was '
                                     f'loaded successfully! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "nlp" does not contain a spaCy language ' \
                     'model. Did you use the load() function from spaCy? ' \
                     'Remember to check the input to the load() function ' \
                     'as well.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except OSError:

            # Define error message
            errmsg = 'The language model could not be loaded. Did you give ' \
                     'the correct name for the language model?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ProcessText(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare cell
        prepare_cell(nb.cells[exercises['process_text']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['process_text']]

    @points('p4.3.create_doc')
    def test_create_doc(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if variable exists
            assert 'doc' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "doc" was '
                                     f'defined successfully! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "doc" has not been defined. Remember to ' \
                     'store the Doc object under the correct variable!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.3.doc_type')
    def test_doc_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['doc']) == spacy.tokens.doc.Doc

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The Doc object was '
                                     f'created successfully! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The object under the variable "doc" does not contain a ' \
                     'spaCy Doc object.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.3.doc_value')
    def test_doc_value(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['doc'].text == "Wells Griffith, a White House adviser on energy, " \
                                           "is one of several witnesses called on to testify " \
                                           "before House impeachment investigators this week. " \
                                           "He is scheduled to be deposed Tuesday, but it's " \
                                           "unclear whether he will appear. All four witnesses " \
                                           "supposed to testify Monday did not show, and several" \
                                           " others scheduled for this week have indicated they " \
                                           "are not coming."

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The Doc object '
                                     f'contains the correct content! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The Doc object does not contain the correct content. ' \
                     'Check your input to the language model!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class GetSentences(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare cell
        prepare_cell(nb.cells[exercises['get_sentences']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['get_sentences']]

    @points('p4.4.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if variable exists
            assert 'sentences' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"sentences" was defined'
                                     f' successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "sentences" has not been defined. Did you ' \
                     'assign the result under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.4.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['sentences']) == list

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "sentences"'
                                     f' contains a list! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "sentences" does not contain a list. Did ' \
                     'you remember to cast the output into a list?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.4.variable_len')
    def test_variable_len(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert len(locals()['sentences']) == 3

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The list stored under '
                                     f'the variable "sentences" has the '
                                     f'correct length! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The list under the variable "sentences" does not have ' \
                     'the correct length! Did you process the correct text ' \
                     'in the previous exercise?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class GetPosTag(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare cell
        prepare_cell(nb.cells[exercises['get_pos']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['get_pos']]

    @points('p4.5.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if variable exists
            assert 'my_tag' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"my_tag" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "my_tag" has not been defined. Did you ' \
                     'assign the result under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.5.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['my_tag']) == str

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "my_tag"'
                                     f' contains a string! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "my_tag" does not contain a string. Did ' \
                     'you fetch the right attribute?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.5.variable_value')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['my_tag'] == locals()['doc'][-60].tag_

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "my_tag" '
                                     f'contains the correct value! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "my_tag" does not contain the correct ' \
                     'value. Did you fetch the right Token from the Doc object?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        except IndexError:

            # Define error message
            errmsg = 'The spaCy Doc object seems to be of wrong length. Did ' \
                     'you process the text correctly in previous exercises ' \
                     'in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class GetDepTag(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare cell
        prepare_cell(nb.cells[exercises['get_dep']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['get_dep']]

    @points('p4.6.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if variable exists
            assert 'sd' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "sd" '
                                     f'was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "sd" has not been defined. Did you ' \
                     'assign the result under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except IndexError:

            # Define error message
            errmsg = 'The spaCy Doc object seems to be of wrong length. Did ' \
                     'you process the text correctly in previous exercises ' \
                     'in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:
            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.6.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['sd']) == str

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "my_tag"'
                                     f' contains a string! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "sd" does not contain a string. Did you ' \
                     'fetch the right attribute?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        except IndexError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.6.variable_value')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['sd'] == locals()['doc'][-65].dep_

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "sd" '
                                     f'contains the correct value! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "sd" does not contain the correct ' \
                     'value. Did you fetch the right Token from the Doc object?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        except IndexError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class GetNer(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare cell
        prepare_cell(nb.cells[exercises['get_ner']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['get_ner']]

    @points('p4.7.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)
            exec(nb.cells[exercises['get_sentences']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if variable exists
            assert 'entities' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "entities" '
                                     f'was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "entities" has not been defined. Did you ' \
                     'assign the result under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.7.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)
            exec(nb.cells[exercises['get_sentences']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['entities']) == list

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "entities"'
                                     f' contains a list! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "entities" does not contain a list. Did ' \
                     'you fetch the correct attribute?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p4.7.variable_len')
    def test_variable_len(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['import_spacy']].source)
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['process_text']].source)
            exec(nb.cells[exercises['get_sentences']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert len(locals()['entities']) == 5

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The list stored under '
                                     f'the variable "entities" has the '
                                     f'correct length! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The list under the variable "entities" does not have ' \
                     'the correct length! Did you process the correct text ' \
                     'in the previous exercise?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)
