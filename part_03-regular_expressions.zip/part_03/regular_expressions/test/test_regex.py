#!/usr/bin/env python3
import pathlib

import nbformat
import unittest
import re

# Import libraries
from tmc import points
from tmc.utils import get_stdout
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'regular_expressions.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}


class ImportRe(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['import_re']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['import_re']]

    @points('p3.1.import_re')
    def test_import_re(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 're' in dir()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The module "re" was imported successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The module "re" was not imported successfully into Python. Please check ' \
                     'the import command!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class DefineRe(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['define_re']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['define_re']]

    @points('p3.2.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'pattern' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"pattern" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pattern" has not been defined. Did you ' \
                     'store the pattern under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.2.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['pattern']) == str

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "pattern"'
                                     f' contains a string object! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pattern" does not contain a string object. Remember that the ' \
                     'regular expression must be defined using a string object!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.2.pattern_definition', 'p3.2.re_applied', 'p3.2.matches_found',
            'p3.2.matches_found_x2', 'p3.2.matches_found_x3', 'p3.2.matches_found_x4',
            'p3.2.matches_found_x5', 'p3.2.matches_found_x6', 'p3.2.matches_found_x7')
    def test_pattern_definition(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_re']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Define a test string
            test_string = "<h1>This <i>is</i> some text surrounded by tags.</h1>"

            # Get matches
            matches = re.findall(locals()['pattern'], test_string)

            # Check if a correct number of matches can be found
            assert len(matches) == 4

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}Your regular expression could find both '
                                     f'opening and closing tags! 9 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'Your regular expression could not find both opening and closing tags. Did ' \
                     'you use all the parts of a regular expression mentioned in the exercise?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class CompileRe(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['compile_re']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['compile_re']]

    @points('p3.3.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['define_re']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'tags' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"tags" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "tags" has not been defined. Did you ' \
                     'store the pattern under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.3.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['define_re']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable 'tags' is of the correct type
            assert type(locals()['tags']) == re.Pattern

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "tags" contains a Pattern '
                                     f'object! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "tags" does not contain a Pattern object! Did ' \
                     'you use the compile() function correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.3.pattern_compiled')
    def test_pattern_compiled(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['define_re']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the attribute 'patterns' contains the correct value
            assert type(locals()['tags'].pattern) == str

            # Check that the pattern is not an empty string
            assert locals()['tags'].pattern != ""

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "tags" contains a pattern '
                                     f'for a regular expression! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "tags" does not contain a pattern for regular expression! Did ' \
                     'you use the compile() function correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ApplyRe(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['apply_re']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['apply_re']]

    @points('p3.4.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['define_re']].source)
            exec(nb.cells[exercises['compile_re']].source)
            exec(nb.cells[exercises['orig_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'updated_text' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "updated_text" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "updated_text" has not been defined. Did you ' \
                     'store the results under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.4._variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['define_re']].source)
            exec(nb.cells[exercises['compile_re']].source)
            exec(nb.cells[exercises['orig_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check that the variable 'updated_text' is of the correct type
            assert type(locals()['updated_text']) == str

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "updated_text" contains a '
                                     f'string object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "updated_text" does not contain a string object. Did you ' \
                     'apply the sub() method correctly to the variable "text"?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    def test_print_original_text(self):

        # Run the previous exercise cells for preliminaries
        exec(nb.cells[exercises['define_re']].source)
        exec(nb.cells[exercises['compile_re']].source)
        exec(nb.cells[exercises['orig_text']].source)

        # Run the cell within the function for local scope
        exec(nb.cells[exercises['print_text']].source)

        # Get the output and prepare for writing to the cell
        stdout = {'text': get_stdout(),
                  'name': 'stdout'}

        # Write the output to the cell before tests
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=nb.cells[exercises['print_text']],
                     output_type='stream',
                     data=stdout,
                     execution_count=nb.cells[exercises['print_text']].execution_count)

    @points('p3.4.tags_removed', 'p3.4.re_applied')
    def test_remove_tags(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_re']].source)
            exec(nb.cells[exercises['define_re']].source)
            exec(nb.cells[exercises['compile_re']].source)
            exec(nb.cells[exercises['orig_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Get matches
            matches = re.findall(r'<.\w{0,}>', locals()['updated_text'])

            # Check if a correct number of matches can be found
            assert len(matches) == 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}Your regular expression could find and '
                                     f'remove all tags from the string object under "text"! '
                                     f'2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'Your regular expression could not find all opening and closing tags. Check ' \
                     'your definition of regular expression!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.4.correct_output')
    def test_apply_re(self):

        # Run the previous exercise cells for preliminaries
        exec(nb.cells[exercises['define_re']].source)
        exec(nb.cells[exercises['compile_re']].source)
        exec(nb.cells[exercises['orig_text']].source)

        # Run the cell within the function for local scope
        exec(self.cell.source)

        # Get the output and prepare for writing to the cell
        stdout = {'text': get_stdout(),
                  'name': 'stdout'}

        # Write the output to the cell before tests
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='stream',
                     data=stdout,
                     execution_count=self.cell.execution_count)

        # Perform test
        try:

            # Check that the variable has been printed
            assert get_stdout() == """In literary theory, a text is any object that can be "read", whether this object is a work of literature, a street sign, an arrangement of buildings on a city block, or styles of clothing. It is a coherent set of signs that transmits some kind of informative message. This set of signs is considered in terms of the informative message's content, rather than in terms of its physical form or the medium in which it is represented."""

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The string object under the variable '
                                     f'"updated_text" was printed successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'Your solution did not print the string object! Did you remember to use the ' \
                     'print() function to print the string object stored under "updated_text"?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ImportPath(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['import_path']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['import_path']]

    @points('p3.5.import_path')
    def test_import_path(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'Path' in dir()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The class "Path" was imported successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The module "Path" was not imported successfully into Python. Please check ' \
                     'the import command!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class CreatePath(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['create_path']])

    def setUp(self):
        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['create_path']]

    @points('p3.6.variable_exists')
    def test_variable_exists(self):

        # Run the previous exercise cell for preliminaries
        exec(nb.cells[exercises['import_path']].source)

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'data' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"data" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "data" has not been defined. Did you ' \
                     'assign the result under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.6.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_path']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable 'tags' is of the correct type
            assert type(locals()['data']) == pathlib.PosixPath

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "data" contains a PosixPath '
                                     f'object! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "data" does not contain a PosixPath object! Did ' \
                     'you use the Path class correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.6.variable_value', 'p3.6.variable_value_x2')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_path']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable 'tags' is of the correct type
            assert locals()['data'] == pathlib.Path('txt')

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "data" contains the expected '
                                     f'values! 2 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "data" does not contain the expected values! Did ' \
                     'you use the Path class correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class GlobPath(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['glob_path']])

    def setUp(self):
        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['glob_path']]

    @points('p3.7.variable_exists')
    def test_variable_exists(self):

        # Run the previous exercise cell for preliminaries
        exec(nb.cells[exercises['import_path']].source)
        exec(nb.cells[exercises['create_path']].source)

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'texts' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"texts" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "texts" has not been defined. Did you ' \
                     'assign the result under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.7.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_path']].source)
            exec(nb.cells[exercises['create_path']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable 'tags' is of the correct type
            assert type(locals()['texts']) == list

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "texts" contains a list '
                                     f'object! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "texts" does not contain a list object! Did ' \
                     'you use the glob() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p3.7.variable_value', 'p3.7.variable_value_x2', 'p3.7.variable_value_x3')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_path']].source)
            exec(nb.cells[exercises['create_path']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable 'tags' is of the correct type
            assert locals()['texts'] == list(pathlib.Path().glob('txt/*.txt'))

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "texts" contains the expected '
                                     f'values! 3 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "texts" does not contain the expected values! Did ' \
                     'you provide the correct input to the glob() method?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)