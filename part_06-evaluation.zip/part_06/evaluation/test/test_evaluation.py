#!/usr/bin/env python3

import nbformat
import unittest
import numpy as np
import sklearn

from tmc import points
from tmc.utils import get_stdout
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'evaluation.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}


class ImportModule(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['import_submodule']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['import_submodule']]

    @points('p6.1.import_submodule')
    def test_import_submodule(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'metrics' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The submodule "metrics" was imported '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The submodule "metrics" was not imported successfully. Did you import the ' \
                     'correct submodule?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class MeasureKappa(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['measure_kappa']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['measure_kappa']]

    @points('p6.2.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'kappa' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "kappa" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "kappa" has not been defined. Did you assign the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.2.kappa_applied', 'p6.2.kappa_type')
    def test_kappa_measure(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['kappa']) == np.float64

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The kappa measure was applied '
                                     f'successfully! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The kappa measure did not return a float. Did you provide the ' \
                     'correct input to the cohen_kappa_score() function?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.2.kappa_value')
    def test_kappa_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert round(locals()['kappa'], 5) == -0.05512

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The kappa measure has the correct value! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The kappa measure did not return the correct value. Did you provide the ' \
                     'correct input to the cohen_kappa_score() function?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ConfMatrix(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['conf_matrix']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['conf_matrix']]

    def test_print_conf_matrix(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Get the output and prepare for writing to the cell
            stdout = {'text': get_stdout(),
                      'name': 'stdout'}

            # Write the output to the cell before tests
            write_result(nb=nb,
                         nb_path=nb_path,
                         cell=nb.cells[exercises['conf_matrix']],
                         output_type='stream',
                         data=stdout,
                         execution_count=nb.cells[exercises['conf_matrix']].execution_count)

            # Set flag
            fail = False

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

            # Write the result to the cell
            write_result(nb=nb,
                         nb_path=nb_path,
                         cell=self.cell,
                         output_type='execute_result',
                         data=message,
                         execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.3.cards_exist')
    def test_cards_exist(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'cards' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "cards" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "cards" has not been defined. Did you assign the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.3.cards_value', 'p6.3.cards_value_x2')
    def test_cards_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['cards'] == sklearn.metrics.classification_report(locals()['gold'],
                                                                              locals()['pred'],
                                                                              output_dict=True)['CARDINAL']['support']

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "cards" has the correct '
                                     f'value! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "cards" does not have the correct value. Check the number of ' \
                     'samples present in the data for this class!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.3.geos_exist')
    def test_geos_exist(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'geos' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "geos" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "geos" has not been defined. Did you assign the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.3.geos_value', 'p6.3.geos_value_x2')
    def test_geos_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['geos'] == sklearn.metrics.classification_report(locals()['gold'],
                                                                             locals()['pred'],
                                                                             output_dict=True)['GPE']['precision']

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "geos" has the correct '
                                     f'value! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "geos" does not have the correct value. Did you retrieve the ' \
                     'value from the correct column of the classification report?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.3.events_exist')
    def test_events_exist(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'events' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "events" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "events" has not been defined. Did you assign the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.3.events_value', 'p6.3.events_value_x2')
    def test_events_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['events'] == sklearn.metrics.classification_report(locals()['gold'],
                                                                               locals()['pred'],
                                                                               output_dict=True)['EVENT']['recall']

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "events" has the correct '
                                     f'value! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "events" does not have the correct value. Did you retrieve the ' \
                     'value from the correct column of the classification report?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class Precision(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['precision']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['precision']]

    @points('p6.4.1.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'result' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "result" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "result" has not been defined. Did you assign the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('6.4.1.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['result']) == np.ndarray

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "result" contains a NumPy array! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "result" does not contain a NumPy array! Did you apply the ' \
                     'precision_score() function correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('6.4.1.variable_value', '6.4.1.variable_value_x2')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Define variables
            golds = ['FAC', 'CARDINAL', 'GPE', 'EVENT', 'LAW', 'NORP', 'MONEY', 'CARDINAL', 'CARDINAL', 'MONEY', 'FAC',
                     'MONEY']
            preds = ['CARDINAL', 'EVENT', 'GPE', 'EVENT', 'EVENT', 'NORP', 'MONEY', 'GPE', 'CARDINAL', 'FAC', 'LAW',
                     'MONEY']

            # Check condition
            assert locals()['result'].all() == sklearn.metrics.precision_score(golds, preds, average=None,
                                                                               zero_division=0).all()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "result" contains the expected values! '
                                     f'2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "result" does not contain the expected values! Did you apply the ' \
                     'precision_score() function correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class TagSet(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['tags']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['tags']]

    @points('p6.4.2.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)
            exec(nb.cells[exercises['precision']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'tags' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "tags" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "tags" has not been defined. Did you assign the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('6.4.2.variable_value', '6.4.2.variable_value_x2')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)
            exec(nb.cells[exercises['precision']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Define variables
            golds = ['FAC', 'CARDINAL', 'GPE', 'EVENT', 'LAW', 'NORP', 'MONEY', 'CARDINAL', 'CARDINAL', 'MONEY', 'FAC',
                     'MONEY']
            preds = ['CARDINAL', 'EVENT', 'GPE', 'EVENT', 'EVENT', 'NORP', 'MONEY', 'GPE', 'CARDINAL', 'FAC', 'LAW',
                     'MONEY']

            # Check condition
            assert locals()['tags'] == list(sorted(set(golds + preds)))

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "tags" contains the expected values! '
                                     f'2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "tags" does not contain the expected values! Did you apply the ' \
                     'set() and sorted() functions to the input data?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('6.4.2.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)
            exec(nb.cells[exercises['precision']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['tags']) == list

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "tags" contains a list! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "tags" does not contain a list! Did you remember to cast the ' \
                     'output into a list?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class TagScores(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['scores']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['scores']]

    @points('6.4.3.variable_value')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)
            exec(nb.cells[exercises['precision']].source)
            exec(nb.cells[exercises['tags']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            test_dict = {'CARDINAL': 0.5,
                         'EVENT': 0.3333333333333333,
                         'FAC': 0.0,
                         'GPE': 0.5,
                         'LAW': 0.0,
                         'MONEY': 1.0,
                         'NORP': 1.0}

            # Check condition
            assert locals()['scores'] == test_dict

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "scores" contains the '
                                     f'expected values! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "scores" does not contain the expected values! Did you apply the ' \
                     'dict() and zip() functions correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p6.4.3.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)
            exec(nb.cells[exercises['precision']].source)
            exec(nb.cells[exercises['tags']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'scores' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "scores" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "scores" has not been defined. Did you assign the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('6.4.3.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_submodule']].source)
            exec(nb.cells[exercises['conf_matrix_data']].source)
            exec(nb.cells[exercises['precision']].source)
            exec(nb.cells[exercises['tags']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['scores']) == dict

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "scores" contains a dictionary! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "scores" does not contain a dictionary! Did you remember to cast the ' \
                     'output into a dictionary?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)