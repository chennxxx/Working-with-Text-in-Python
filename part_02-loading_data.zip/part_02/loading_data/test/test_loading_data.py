#!/usr/bin/env python3

import nbformat
import unittest
import io

# Import libraries
from tmc import points
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'loading_data.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}


class LoadFile(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['load_file']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['load_file']]

    @points('p2.1.variable_exists')
    def test_variable_text_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'text' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"text" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "text" has not been defined. Did you ' \
                     'assign the result under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except FileNotFoundError:

            # Define error message
            errmsg = 'Failed to open the file. Did you provide the correct path to the open() ' \
                     'function and in the correct format?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.1.variable_exists_x2')
    def test_variable_f_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'f' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"f" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "f" has not been defined. Did you ' \
                     'assign the file opened using the "with" statement ' \
                     'under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.1.variable_type')
    def test_variable_f_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['f']) == io.TextIOWrapper

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "f"'
                                     f' contains a TextIOWrapper object! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "f" does not contain a TextIOWrapper object. Did you use ' \
                     'the open() function correctly? '

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.1.variable_path')
    def test_variable_path(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['f'].name == 'txt/WP_1990-08-10-25A.txt'

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "f" contains a path to '
                                     f'the correct file! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The object stored under the variable "f" does not contain a path to the ' \
                     'correct file. Did you provide the correct input to the open() function?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.1.variable_encoding')
    def test_variable_encoding(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['f'].encoding.lower() == 'utf-8'

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "f" has the correct '
                                     f'type of encoding (UTF-8)! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The object stored under the variable "f" does not have the right kind ' \
                     'of encoding. Did you remember to instruct Python to use UTF-8 encoding?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.1.variable_type_x2')
    def test_variable_text_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['text']) == str

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "text" contains a string '
                                     f'object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The object stored under the variable "text" does not contain the correct ' \
                     'type of object (a string). Did you remember to read the file contents?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'The object stored under the variable "text" does not contain the correct ' \
                     'type of object (a string). Did you read the text from the correct file?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:
            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.1.variable_value')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['text'] == open('txt/WP_1990-08-10-25A.txt', encoding='UTF-8').read()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "text" '
                                     f'contains the correct value! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "text" does not contain the correct ' \
                     'value. Did you use the read() method to read the file contents?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ReplaceText(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['replace_text']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['replace_text']]

    @points('p2.3.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'copyright' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"copyright" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "copyright" has not been defined. Did you ' \
                     'assign the sentences under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.3.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['copyright']) == str

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "copyright"'
                                     f' contains a string object! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "copyright" does not contain a string object. Did you assign ' \
                     'the value correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.3.variable_value')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Set copyright text to be checked
            copytext = 'Reproduced with permission of the copyright owner. ' \
                       'Further reproduction prohibited without permission.'

            # Check if the variable contains the correct value
            assert locals()['copyright'] == copytext

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "copyright" '
                                     f'contains the correct value! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "copyright" does not contain the correct ' \
                     'value. Did you assign the correct value to this variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ReplaceValue(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['replace_value']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['replace_value']]

    @points('p2.3.replace_value')
    def test_replace_value(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['load_file']].source)
            exec(nb.cells[exercises['replace_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['copyright'] not in locals()['text']

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The string stored under the variable '
                                     f'"copyright" was successfully removed from the string under '
                                     f'"text"! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The string stored under the variable "copyright" could be found in the ' \
                     'string under "text". Did you define the value of "copyright" correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables from previous exercises remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class DefinePattern(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['define_pattern']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['define_pattern']]

    @points('p2.4.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'pipeline' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable '
                                     f'"pipeline" was defined successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pipeline" has not been defined. Did you ' \
                     'assign the patterns under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.4.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['pipeline']) == list

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "pipeline" contains a list '
                                     f'object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pipeline" does not contain a list object. Did you assign ' \
                     'the value correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:
            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.4.item_values')
    def test_item_values(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert type(locals()['pipeline'][0]) == tuple
            assert type(locals()['pipeline'][1]) == tuple

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The items stored in the list "pipeline" are '
                                     f'of the correct type (tuple)! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The items stored in the list "pipeline" are not of the correct type! Did ' \
                     'you remember to define the patterns using tuples?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:
            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p2.4.variable_values')
    def test_variable_values(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert locals()['pipeline'][0][0] == "-, "
            assert locals()['pipeline'][0][1] == ""
            assert locals()['pipeline'][1][0] == ",,,,"
            assert locals()['pipeline'][0][1] == ""

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The tuples stored in the list "pipeline" '
                                     f'contain the correct values! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The tuples stored in the list "pipeline" do not contain the correct values.' \
                     ' Did you provide the correct patterns when defining the tuples?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:
            # Use the fail method to fail the test
            self.fail(errmsg)


class ApplyPattern(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['apply_pattern']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['apply_pattern']]

    @points('p2.5.variable_exists', 'p2.5.variable_exists_x2', 'p2.5.variable_exists_x3',
            'p2.5.variable_exists_x4', 'p2.5.variable_exists_x5')
    def test_pattern_applied(self):

        # Perform test
        try:

            # Run the previous exercise cells for preliminaries
            exec(nb.cells[exercises['load_file']].source)
            exec(nb.cells[exercises['define_pattern']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable contains the correct value
            assert "-, " not in locals()['text']
            assert ",,,," not in locals()['text']

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The patterns defined using the tuples in '
                                     f'the list "pipeline" were successfully removed from the '
                                     f'string stored under the variable "text"! 5 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The patterns defined using the tuples in the list "pipeline" could still ' \
                     'be found in the string object under the variable "text". Did you define the ' \
                     'patterns correctly? Did you retrieve them successfully during the for loop?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables from previous exercises remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)
