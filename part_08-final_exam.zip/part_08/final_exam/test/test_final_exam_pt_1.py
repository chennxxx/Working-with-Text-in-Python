#!/usr/bin/env python3

import nbformat
import unittest
import re
from pathlib import Path

from tmc import points
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'final_exam_part_i.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}

# Check if the exercise should be graded
if 'grade' in exercises:

    # Run grade cell
    exec(nb.cells[exercises['grade']].source)

    if locals()['grade'] in [False, None]:

        grade = False

    else:

        grade = True


class CheckGrading(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['grade']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['grade']]

    def test_grade_true(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['grade']

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}This Notebook will be graded.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'This Notebook will not be graded. Set the "grade" variable to True if you ' \
                     'wish this Notebook to be graded.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class LoadAndReadData(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['load_text']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['load_text']]

    @points('wtp-fe-1-1_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'wiki_articles' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "wiki_articles" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "wiki_articles" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-1_variable_type', 'wtp-fe-1-1_variable_type_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert all(isinstance(x, str) for x in locals()['wiki_articles']) \
                   and len(locals()['wiki_articles']) > 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "wiki_articles" contains '
                                     f'string objects! 2 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "wiki_articles" does not contain string objects.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-1_variable_value', 'wtp-fe-1-1_variable_value_x2',
            'wtp-fe-1-1_variable_value_x3', 'wtp-fe-1-1_variable_value_x4',
            'wtp-fe-1-1_variable_value_x5', 'wtp-fe-1-1_variable_value_x6',
            'wtp-fe-1-1_variable_value_x7', 'wtp-fe-1-1_variable_value_x8',
            'wtp-fe-1-1_variable_value_x9', 'wtp-fe-1-1_variable_value_x10',
            'wtp-fe-1-1_variable_value_x11', 'wtp-fe-1-1_variable_value_x12')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['wiki_articles'] == [x.read_text(encoding='utf-8') for x in
                                                 Path('data/wiki').glob('*xt')]

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "wiki_articles" contains the '
                                     f'expected values! 12 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "wiki_articles" does not contain the expected values.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class DefineAndApplyRE(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['apply_re']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['apply_re']]

    @points('wtp-fe-1-2_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'pattern' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "pattern" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pattern" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Your code raised a NameError, which indicates that your code refers to a variable ' \
                     'that has not been defined. If you are sure that your code is correct, please check ' \
                     'if you used a list comprehension to apply the regular expression to the texts. For ' \
                     'some reason, using a list comprehension causes the tests to fail. Use a for loop ' \
                     'instead.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-2_variable_exists_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists_2(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'clean_articles' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "clean_articles" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "clean_articles" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-2_variable_type')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert all(isinstance(x, str) for x in locals()['clean_articles']) \
                   and len(locals()['clean_articles']) > 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "clean_articles" contains '
                                     f'string objects! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "clean_articles" does not contain string objects.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-2_variable_type_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type_2(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['pattern']) == re.Pattern

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "pattern" contains a regular '
                                     f'expression! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pattern" does not contain a Pattern object.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-2_variable_len')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_len(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert len(locals()['clean_articles']) == 475

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The list "clean_articles" contains the '
                                     f'expected number of items! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The list "clean_articles" does not contain the expected number of items.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-2_variable_value', 'wtp-fe-1-2_variable_value_x2',
            'wtp-fe-1-2_variable_value_x3', 'wtp-fe-1-2_variable_value_x4',
            'wtp-fe-1-2_variable_value_x5', 'wtp-fe-1-2_variable_value_x6',
            'wtp-fe-1-2_variable_value_x7', 'wtp-fe-1-2_variable_value_x8',
            'wtp-fe-1-2_variable_value_x9', 'wtp-fe-1-2_variable_value_x10')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            test_data = ' '.join(x for x in locals()['clean_articles'])

            # Check conditions
            assert len(locals()['clean_articles']) == 475
            assert '==' not in test_data
            assert '===' not in test_data
            assert '====' not in test_data

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The headers were successfully removed from all 475 articles! '
                                     f'10 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The string objects in the list "clean_articles" contain headers.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ExtractHeaders(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['extract_headers']])

    def setUp(self):
        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['extract_headers']]

    @points('wtp-fe-1-3_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'titles' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "titles" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "titles" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-3_variable_type')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['titles']) == dict

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "titles" contains a '
                                     f'dictionary! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "titles" does not contain a dictionary.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-1-3_variable_value', 'wtp-fe-1-3_variable_value_x2',
            'wtp-fe-1-3_variable_value_x3', 'wtp-fe-1-3_variable_value_x4',
            'wtp-fe-1-3_variable_value_x5', 'wtp-fe-1-3_variable_value_x6',
            'wtp-fe-1-3_variable_value_x7', 'wtp-fe-1-3_variable_value_x8',
            'wtp-fe-1-3_variable_value_x9', 'wtp-fe-1-3_variable_value_x10',
            'wtp-fe-1-3_variable_value_x11', 'wtp-fe-1-3_variable_value_x12',
            'wtp-fe-1-3_variable_value_x13')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['extract_headers']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check conditions
            assert locals()['titles'] == {y.name: y.read_text(encoding='utf-8').split('\n\n')[0]
                                          for y in Path('data/wiki').glob('*xt')}

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The dictionary "titles" contains the '
                                     f'expected items! 13 points. {Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The dictionary "titles" does not contain the expected items.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)
