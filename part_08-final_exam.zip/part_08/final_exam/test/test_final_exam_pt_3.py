#!/usr/bin/env python3

import nbformat
import unittest
import numpy as np
import pandas as pd
from spacy.tokens import Doc, Span
from tmc import points
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'final_exam_part_iii.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}

# Check if the exercise should be graded
if 'grade' in exercises:

    # Run grade cell
    exec(nb.cells[exercises['grade']].source)

    if locals()['grade'] in [False, None]:

        grade = False

    else:

        grade = True


class CheckGrading(unittest.TestCase):

    @classmethod

    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['grade']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['grade']]

    def test_grade_true(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['grade']

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}This Notebook will be graded.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'This Notebook will not be graded. Set the "grade" variable to True if you ' \
                     'wish this Notebook to be graded.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class LoadDocs(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['load_docs']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['load_docs']]

    @points('wtp-fe-3-1_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'small_docs' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "small_docs" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "small_docs" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-1_variable_exists_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists_2(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'medium_docs' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "medium_docs" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "medium_docs" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-1_variable_type')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert all(isinstance(x, Doc) for x in locals()['small_docs']) \
                   and len(locals()['small_docs']) > 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "small_docs" contains '
                                     f'Doc objects! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "small_docs" does not contain Doc objects.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-1_variable_type_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type_2(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert all(isinstance(x, Doc) for x in locals()['medium_docs']) \
                   and len(locals()['medium_docs']) > 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "medium_docs" contains '
                                     f'Doc objects! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "medium_docs" does not contain Doc objects.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-1_variable_value', 'wtp-fe-3-1_variable_value_x2',
            'wtp-fe-3-1_variable_value_x3', 'wtp-fe-3-1_variable_value_x4',
            'wtp-fe-3-1_variable_value_x5', 'wtp-fe-3-1_variable_value_x6',
            'wtp-fe-3-1_variable_value_x7', 'wtp-fe-3-1_variable_value_x8',
            'wtp-fe-3-1_variable_value_x9', 'wtp-fe-3-1_variable_value_x10',
            'wtp-fe-3-1_variable_value_x11')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Target texts
            check = ['AMATIL', 'BELL', 'BOWATER', 'CITIBANK', 'CRA', 'GERMAN', 'JAPAN', 'JAPANESE',
                     'JARDINE', 'SOUTH']

            # Check condition
            assert sorted([x[0].text for x in locals()['small_docs'][:10]]) == sorted(check)
            assert sorted([x[0].text for x in locals()['medium_docs'][:10]]) == sorted(check)

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variables "small_docs" and "medium_docs" '
                                     f'contain the expected values! 11 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variables "small_docs" and "medium_docs" do not contain the expected values.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class Precision(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['calc_pr']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['calc_pr']]

    @points('wtp-fe-3-2_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_docs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'pr' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "pr" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pr" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-2_variable_type')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_docs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['pr']) == np.float64

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "pr" contains a NumPy float! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pr" does not contain a NumPy float.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-2_variable_value', 'wtp-fe-3-2_variable_value_x2',
            'wtp-fe-3-2_variable_value_x3', 'wtp-fe-3-2_variable_value_x4',
            'wtp-fe-3-2_variable_value_x5', 'wtp-fe-3-2_variable_value_x6',
            'wtp-fe-3-2_variable_value_x7', 'wtp-fe-3-2_variable_value_x8',
            'wtp-fe-3-2_variable_value_x9', 'wtp-fe-3-2_variable_value_x10',
            'wtp-fe-3-2_variable_value_x11', 'wtp-fe-3-2_variable_value_x12',
            'wtp-fe-3-2_variable_value_x13')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_docs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert round(locals()['pr'], 4) == (pow(0.48065, 1) + pow(0.48065, 1))

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "pr" contains the expected '
                                     f'value! 13 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "pr" does not contain the expected value.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class Pandas(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['pandas']])

    def setUp(self):
        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['pandas']]

    @points('wtp-fe-3-3_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'data' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "data" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "data" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-3_variable_exists_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists_2(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'top_pos' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_pos" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_pos" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-3_variable_exists_x3')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists_3(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'top_nouns' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_nouns" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_nouns" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-3_variable_type')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['data']) == pd.DataFrame

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "data" contains a '
                                     f'pandas DataFrame! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "data" does not contain a pandas DataFrame.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:
            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-3_variable_type_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type_2(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['top_pos']) == pd.Series

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_pos" contains a '
                                     f'pandas Series! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_pos" does not contain a pandas Series.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:
            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-3_variable_type_x3')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type_3(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert type(locals()['top_nouns']) == pd.Series

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_nouns" contains a '
                                     f'pandas Series! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_nouns" does not contain a pandas Series.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-3_variable_value', 'wtp-fe-3-3_variable_value_x2',
            'wtp-fe-3-3_variable_value_x3', 'wtp-fe-3-3_variable_value_x4',
            'wtp-fe-3-3_variable_value_x5')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            test_series = pd.Series({'NOUN': 2194,
                                     'PROPN': 1114,
                                     'ADP': 1074,
                                     'VERB': 1044,
                                     'SPACE': 1017})

            # Check condition
            assert locals()['top_pos'].equals(test_series)

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_pos" contains the '
                                     f'expected values! 5 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_pos" does not contain the expected values.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-3-3_variable_value_x6', 'wtp-fe-3-3_variable_value_x7',
            'wtp-fe-3-3_variable_value_x8', 'wtp-fe-3-3_variable_value_x9')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value_2(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            test_series_2 = pd.Series({('pct', 'NOUN'): 57,
                                       ('year', 'NOUN'): 42,
                                       ('dlrs', 'NOUN'): 36,
                                       ('oil', 'NOUN'): 35,
                                       ('mln', 'NOUN'): 30})

            # Check condition
            assert locals()['top_nouns'].equals(test_series_2)

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_nouns" contains the '
                                     f'expected values! 4 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_nouns" does not contain the expected values.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)