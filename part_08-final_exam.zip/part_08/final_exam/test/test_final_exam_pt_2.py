#!/usr/bin/env python3

import nbformat
import unittest
from spacy.tokens import Doc, Span
from tmc import points
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'final_exam_part_ii.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}

# Check if the exercise should be graded
if 'grade' in exercises:

    # Run grade cell
    exec(nb.cells[exercises['grade']].source)

    if locals()['grade'] in [False, None]:

        grade = False

    else:

        grade = True


class CheckGrading(unittest.TestCase):

    @classmethod

    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['grade']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['grade']]

    def test_grade_true(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['grade']

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}This Notebook will be graded.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'This Notebook will not be graded. Set the "grade" variable to True if you ' \
                     'wish this Notebook to be graded.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class LoadAndProcessData(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['process_text']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['process_text']]

    @points('wtp-fe-2-1_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'speeches' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "speeches" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "speeches" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-2-1_variable_type', 'wtp-fe-2-1_variable_type_x2')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert all(isinstance(x, Doc) for x in locals()['speeches']) \
                   and len(locals()['speeches']) > 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "speeches" contains '
                                     f'Doc objects! 2 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "speeches" does not contain Doc objects.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-2-1_variable_value', 'wtp-fe-2-1_variable_value_x2',
            'wtp-fe-2-1_variable_value_x3', 'wtp-fe-2-1_variable_value_x4',
            'wtp-fe-2-1_variable_value_x5', 'wtp-fe-2-1_variable_value_x6',
            'wtp-fe-2-1_variable_value_x7', 'wtp-fe-2-1_variable_value_x8',
            'wtp-fe-2-1_variable_value_x9', 'wtp-fe-2-1_variable_value_x10',
            'wtp-fe-2-1_variable_value_x11', 'wtp-fe-2-1_variable_value_x12')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Target text
            check = ['DWIGHT', 'HARRY', 'JOHN', 'Message', 'RONALD']

            # Check condition
            assert sorted([s[1].text for s in locals()['speeches']]) == sorted(check)

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "speeches" contains the '
                                     f'expected values! 12 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "speeches" does not contain the expected values.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class GetEntities(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['get_entities']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['get_entities']]

    @points('wtp-fe-2-2_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'entities' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "entities" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "entities" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-2-2_variable_type')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert all(isinstance(x, Span) for x in locals()['entities'])\
                   and len(locals()['entities']) > 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "entities" contains '
                                     f'Span objects! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "entities" does not contain Span objects.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-2-2_variable_value', 'wtp-fe-2-2_variable_value_x2',
            'wtp-fe-2-2_variable_value_x3', 'wtp-fe-2-2_variable_value_x4',
            'wtp-fe-2-2_variable_value_x5', 'wtp-fe-2-2_variable_value_x6',
            'wtp-fe-2-2_variable_value_x7', 'wtp-fe-2-2_variable_value_x8',
            'wtp-fe-2-2_variable_value_x9', 'wtp-fe-2-2_variable_value_x10',
            'wtp-fe-2-2_variable_value_x11', 'wtp-fe-2-2_variable_value_x12',
            'wtp-fe-2-2_variable_value_x13')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Target texts
            check = ["DWIGHT D. EISENHOWER'S", "JOHN F. KENNEDY'S", "RONALD REAGAN'S",
                     "HARRY S. TRUMAN'S", 'Congress', 'THE CONGRESS ON URGENT NATIONAL NEEDS',
                     'January 22, 1970', 'CONGRESS', 'April 16, 1945', 'Speaker']

            # Check condition
            assert sorted([x.text for x in sorted(locals()['entities'])[:10]]) == sorted(check)

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "entities" contains the '
                                     f'expected values! 12 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "entities" does not contain the expected values.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class GetVerbs(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['get_verbs']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['get_verbs']]

    @points('wtp-fe-2-3_variable_exists')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'verbs' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "verbs" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "verbs" has not been defined.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-2-3_variable_type')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert all(isinstance(x, str) for x in locals()['verbs'])\
                   and len(locals()['verbs']) > 0

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "verbs" contains '
                                     f'string objects! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "verbs" does not contain string objects.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('wtp-fe-2-3_variable_value', 'wtp-fe-2-3_variable_value_x2',
            'wtp-fe-2-3_variable_value_x3', 'wtp-fe-2-3_variable_value_x4',
            'wtp-fe-2-3_variable_value_x5', 'wtp-fe-2-3_variable_value_x6',
            'wtp-fe-2-3_variable_value_x7', 'wtp-fe-2-3_variable_value_x8',
            'wtp-fe-2-3_variable_value_x9', 'wtp-fe-2-3_variable_value_x10',
            'wtp-fe-2-3_variable_value_x11', 'wtp-fe-2-3_variable_value_x12',
            'wtp-fe-2-3_variable_value_x13')
    @unittest.skipIf(not grade, "The 'grade' variable is not set to True.")
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['process_text']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Target texts
            check = ['-', '-an', 'ABROAD', 'DISARMAMENT', 'abandon', 'abate', 'abide', 'abolish',
                     'abolish', 'absorb']

            # Check condition
            assert sorted([x for x in sorted(locals()['verbs'])[:10]]) == sorted(check)

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "verbs" contains the '
                                     f'expected values! 12 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "verbs" does not contain the expected values.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)
