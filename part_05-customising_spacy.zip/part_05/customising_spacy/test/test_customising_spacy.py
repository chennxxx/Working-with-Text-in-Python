#!/usr/bin/env python3

import nbformat
import unittest
import spacy

from pathlib import Path
from spacy.tokens import DocBin
from tmc import points
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'customising_spacy.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}


class LoadModel(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['load_model']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['load_model']]

    @points('p5.1.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'nlp_no_ner' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "nlp_no_ner" was '
                                     f'defined successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "nlp_no_ner" has not been defined. Did you ' \
                     'store the model under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.1.model_loaded', 'p5.1.ner_disabled')
    def test_model_loaded(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'ner' not in [x[0] for x in locals()['nlp_no_ner'].pipeline]

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The language model was successfully loaded '
                                     f'without the Named Entity Recognition component! 2 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The language model was not loaded without the Named Entity Recognition ' \
                     'component.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ImportDoc(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['import_doc']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['import_doc']]

    @points('p5.2.import_doc')
    def test_import_doc(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'Doc' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The Doc object was imported successfully! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The Doc object was not imported successfully. Check your use of the import ' \
                     'command!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.2.doc_type')
    def test_doc_type(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['Doc'] == spacy.tokens.doc.Doc

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The Doc object is of the correct type! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The object stored under the name "Doc" is not a spaCy Doc object!'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class AddAttribute(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['add_attribute']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['add_attribute']]

    @points('p5.3.attribute_exists', 'p5.3.attribute_exists_x2')
    def test_attribute_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_doc']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['Doc'].has_extension("source")

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The attribute "source" was successfully '
                                     f'added to the Doc object! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The attribute "source" was not added to the Doc object. Did you ' \
                     'call the set_extension() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.3.attribute_default_value')
    def test_default_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_doc']].source)

            # Get attributes from Doc object
            attributes = locals()['Doc'].get_extension("source")

            # Check condition
            assert attributes[0] is None

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The default value of the "source" attribute '
                                     f'was correctly set to None! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The default value of the "source" attribute was not set to None. Did you ' \
                     'set the default value for the custom attribute?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except TypeError:

            # Define error message
            errmsg = 'Failed to retrieve attributes from the object. Did you define the Doc ' \
                     'object correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class PipeDocs(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['pipe_docs']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['pipe_docs']]

    @points('p5.4.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable exists
            assert 'docs' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "docs" '
                                     f'was defined successfully! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "docs" has not been defined. Did you assign the output ' \
                     'from the pipe() method under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.4.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['docs']) == list

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "docs" is a list object! '
                                     f'1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "docs" does not contain a list object! Did you apply ' \
                     'the pipe() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.

            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.4.variable_len')
    def test_variable_len(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the list is of correct length
            assert len(locals()['docs']) == 4

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "docs" contains the '
                                     f'correct number of items! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "docs" does not contain four items! Did you apply the ' \
                     'pipe() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.4.item_types')
    def test_item_types(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Collect item types
            item_types = set([type(x) for x in locals()['docs']])

            # Check item types
            assert list(item_types)[0] == spacy.tokens.doc.Doc

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "docs" contains '
                                     f'spaCy Doc objects! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "docs" does not contain spaCy Doc objects! Did you ' \
                     'apply the pipe() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('5.4.item_values')
    def test_item_values(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Get paths to text files
            paths = list(Path('data').glob('*.txt'))

            # Read the contents of each file; assign result under 'texts'
            texts = [open(p, encoding="utf-8").read() for p in paths]

            # Collect item types
            doc_contents = [doc.text for doc in locals()['docs']]

            # Check item types
            assert doc_contents == texts

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The spaCy Doc objects under the variable '
                                     f'"docs" contain the correct inputs. 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The spaCy Doc objects under the variable "docs" do not contain the expected' \
                     ' input. Did you apply the pipe() method to the correct input?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class PipeAttributes(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['pipe_attrs']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['pipe_attrs']]

    @points('p5.5.docs_exist', 'p5.5.attributes_exist')
    def test_attributes_exist(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['docs'][0].has_extension("source")

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The Doc objects contained in the list '
                                     f'"docs" have the attribute "source"! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The attribute "source" could not be found in the Doc objects in the list ' \
                     '"docs". Did you remember to assign the custom attribute under the pseudo ' \
                     'attribute "_"?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.5.attribute_values', 'p5.5.attribute_len')
    def test_attribute_values(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Get filenames
            fnames = [x for x in locals()['filenames']]
            attrs = [x._.source for x in locals()['docs']]

            # Check condition
            assert set(fnames) == set(attrs)

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The "source" attributes contain the '
                                     f'correct values! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The attribute "source" does not contain the correct values! Did you assign ' \
                     'the correct value to the attribute?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class CreateDocBin(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['create_docbin']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['create_docbin']]

    @points('p5.6.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)
            exec(nb.cells[exercises['pipe_attrs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable exists
            assert 'my_docs' in locals()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "my_docs" '
                                     f'was defined successfully! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "my_docs" has not been defined. Did you assign the DocBin ' \
                     'object under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.

            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.6.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)
            exec(nb.cells[exercises['pipe_attrs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['my_docs']) == spacy.tokens._serialize.DocBin

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "my_docs"'
                                     f' is a DocBin object! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "my_docs" does not contain a DocBin object! Did you create ' \
                     'a DocBin object?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.6.variable_len')
    def test_variable_len(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)
            exec(nb.cells[exercises['pipe_attrs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the list is of correct length
            assert len(locals()['my_docs']) == 4

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "my_docs" contains the '
                                     f'correct number of items! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "my_docs" does not contain four items! Did you add the Doc ' \
                     'objects to the DocBin?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.6.custom_attributes')
    def test_custom_attrs(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)
            exec(nb.cells[exercises['pipe_attrs']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check that four custom attributes exist
            assert len(locals()['my_docs'].user_data) == 4

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The DocBin object under the '
                                     f'variable "my_docs" contains four custom '
                                     f'attributes! 1 point.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The DocBin object under the variable "my_docs" does not contain ' \
                     'four custom attributes as expected. Did you remember to add the ' \
                     'custom attributes to the DocBin?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class WriteDocBin(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['write_docbin']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['write_docbin']]

    @points('p5.7.file_exists', 'p5.7.file_exists_x2')
    def test_file_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)
            exec(nb.cells[exercises['pipe_attrs']].source)
            exec(nb.cells[exercises['create_docbin']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the file exists
            assert Path('data/my_docs.spacy').exists()

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The DocBin object under the variable '
                                     f'"my_docs" was successfully written to disk! 2 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The DocBin object under the variable "my_docs" was not written ' \
                     'successfully to disk. Did you provide the correct path to the file location?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p5.7.file_type', 'p5.7.file_type_x2')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['load_model']].source)
            exec(nb.cells[exercises['pipe_docs']].source)
            exec(nb.cells[exercises['pipe_attrs']].source)
            exec(nb.cells[exercises['create_docbin']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the file loaded from disk is of the correct type
            assert type(DocBin().from_disk('data/my_docs.spacy')) == spacy.tokens._serialize.DocBin

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The DocBin object written to disk '
                                     f'is of correct type! 2 points.'
                                     f'{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The DocBin object written to disk does not contain a DocBin object. Did ' \
                     'you write the correct object to disk?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)
