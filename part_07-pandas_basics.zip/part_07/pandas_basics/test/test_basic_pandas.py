#!/usr/bin/env python3

import nbformat
import unittest
import sys
import pandas as pd

from tmc import points
from tmc.applt import write_result, prepare_cell, Colors

# Define path to Notebook
nb_path = 'basic_pandas.ipynb'

# Read the notebook
nb = nbformat.read(nb_path, as_version=4)

# Collect indices for notebook cells that contain exercises. Map these indices
# to a dictionary keyed by test names.
exercises = {cell['metadata']['test']: ix for ix, cell in enumerate(nb.cells)
             if 'test' in cell['metadata']}


class ImportModule(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['import_pandas']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['import_pandas']]

    @points('p7.1.import_module')
    def test_import_module(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'pd' in locals()
            assert 'pandas' in sys.modules

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The pandas library was successfully '
                                     f'imported using the alias "pd"! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The pandas library was not imported successfully. Did you import pandas ' \
                     'using the correct alias?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class CreateDataFrame(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['read_csv']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['read_csv']]

    @points('p7.2.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'df' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "df" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "df" has not been defined. Did you store the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except FileNotFoundError:

            # Define error message
            errmsg = 'Could not find the file provided to the read_csv() method. Did you provide ' \
                     'a valid path to the CSV file?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.2.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['df']) == pd.core.frame.DataFrame

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "df" contains a pandas '
                                     f'DataFrame object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "df" does not contain a pandas DataFrame object! Did you ' \
                     'use the read_csv() method?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class InspectDataFrame(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['inspect_df']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['inspect_df']]

    @points('p7.3.1.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'head' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "head" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "head" has not been defined. Did you store the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.3.1.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['head']) == pd.core.frame.DataFrame

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "head" contains a pandas '
                                     f'DataFrame object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "head" does not contain a pandas DataFrame object! Did you ' \
                     'use the head() method?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.3.1.variable_value')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Load the data
            test_head = pd.read_csv('data/gnm_comments_500.csv').head(10)

            # Check if the variable has the correct value
            assert test_head.equals(locals()['head'])

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "head" contains the expected '
                                     f'values! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "head" does not contain the expected values! Did you use the ' \
                     'head() method to fetch the correct number of rows?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.3.1.variable_length')
    def test_variable_length(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable has the correct value
            assert len(locals()['head']) == 10

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "head" contains the expected '
                                     f'number of rows! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "head" does not contain the expected number of rows! Did you ' \
                     'use the head() method to fetch the correct number of rows?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ExamineColumns(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['examine_cols']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['examine_cols']]

    @points('p7.3.2.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'col_length' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "col_length" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "col_length" has not been defined. Did you store the result ' \
                     'under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.3.2.variable_length', 'p7.3.2.variable_length_x2')
    def test_variable_length(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable has the correct value
            assert locals()['col_length'] == 28

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "col_length" contains the '
                                     f'expected number of items! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "col_length" does not contain the expected number of items! ' \
                     'Did you use the len() function to count the columns?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.3.2.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['col_length']) == int

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "col_length" contains an '
                                     f'integer! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "col_length" does not contain an integer! Did you use the ' \
                     'len() function to count the number of columns?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ExamineAuthors(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['examine_auth']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['examine_auth']]

    @points('p7.3.3.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'author' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "author" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "author" has not been defined. Did you store the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.3.3.variable_value', 'p7.3.3.variable_value_x2')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Load the data
            test_head = pd.read_csv('data/gnm_comments_500.csv').head(10)

            # Check if the variable has the correct value
            assert test_head.at[2, 'comment_author'] == locals()['author']

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "author" contains the expected '
                                     f'value! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "author" does not contain the expected value! Did you fetch ' \
                     'the value from the correct column and index?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.3.3.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['author']) == str

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "author" contains a '
                                     f'string object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "author" does not contain a string object! Did you fetch the' \
                     'value from the correct column of the DataFrame?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class CountAuthors(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['count_auth']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['count_auth']]

    @points('p7.4.1.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'authors' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "authors" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "authors" has not been defined. Did you store the result under ' \
                     'the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.4.1.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['authors']) == pd.core.series.Series

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "authors" contains a '
                                     f'pandas Series object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "authors" does not contain a pandas Series object! Did you ' \
                     'apply the value_counts() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.4.1.variable_len', 'p7.4.1.variable_len_x2')
    def test_variable_length(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable has the correct value
            assert len(locals()['authors']) == 190

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "authors" contains the expected '
                                     f'number of rows! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "authors" does not contain the expected number of rows! Did ' \
                     'you count the values in the correct column?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class TopAuthor(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['count_max']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['count_max']]

    @points('p7.4.2.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)
            exec(nb.cells[exercises['count_auth']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'top_author' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_author" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_author" has not been defined. Did you store the result ' \
                     'under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.4.2.variable_value', 'p7.4.2.variable_value_x2')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)
            exec(nb.cells[exercises['count_auth']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Load the data
            test_df = pd.read_csv('data/gnm_comments_500.csv')

            # Check if the variable has the correct value
            assert test_df['comment_author'].value_counts().idxmax() == locals()['top_author']

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_author" contains the '
                                     f'correct value! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_author" does not contain the expected value! Did you use' \
                     'the idxmax() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class TopPosts(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['count_posts']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['count_posts']]

    @points('p7.4.3.variable_exists')
    def test_variable_exists(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)
            exec(nb.cells[exercises['count_auth']].source)
            exec(nb.cells[exercises['count_max']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'top_posts' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_posts" was defined '
                                     f'successfully! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_posts" has not been defined. Did you store the result ' \
                     'under the correct variable?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.4.4.variable_type')
    def test_variable_type(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)
            exec(nb.cells[exercises['count_auth']].source)
            exec(nb.cells[exercises['count_max']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check if the variable is of the correct type
            assert type(locals()['top_posts']) == pd.core.frame.DataFrame

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_posts" contains a '
                                     f'pandas DataFrame object! 1 point.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "authors" does not contain a pandas DataFrame object! Did you ' \
                     'apply the value_counts() method correctly?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.4.4.variable_value', 'p7.4.4.variable_value_x2')
    def test_variable_value(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['inspect_df']].source)
            exec(nb.cells[exercises['count_auth']].source)
            exec(nb.cells[exercises['count_max']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Load the data
            test_df = pd.read_csv('data/gnm_comments_500.csv')
            top_a = test_df['comment_author'].value_counts().idxmax()
            top_p = test_df.loc[test_df['comment_author'] == top_a]

            # Check if the variable has the correct value
            assert locals()['top_posts'].equals(top_p)

            # Define a message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The variable "top_posts" contains the '
                                     f'expected value! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The variable "top_posts" does not contain the expected value! Did you use' \
                     'count the values from the right column?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Fail silently. The previous test will raise an error message.
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class WriteFunction(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['write_func']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['write_func']]

    @points('p7.5.function_exists', 'p7.5.function_created')
    def test_function_exist(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'comm_len' in locals()

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The function "comm_len" was defined '
                                     f'successfully! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The function "comm_len" has not been defined. Did you name the function ' \
                     'as instructed?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.5.function_applied', 'p7.5.function_works', 'p7.5.function_output',
            'p7.5.function_output_x2', 'p7.5.function_output_x3')
    def test_apply_function(self):

        # Perform test
        try:

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert locals()['comm_len']("hello world") == 2
            assert locals()['comm_len']("hello world yeah") == 3

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The function "comm_len" returned the '
                                     f'expected output! 5 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The function "comm_len" does not return the expected output. Did you ' \
                     'remember to return the number of items in the list?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)


class ApplyFunction(unittest.TestCase):

    @classmethod
    def setUpClass(cls):

        # Prepare the cell by clearing outputs
        prepare_cell(nb.cells[exercises['apply_func']])

    def setUp(self):

        # Get the cell that is to be tested
        self.cell = nb.cells[exercises['apply_func']]

    @points('p7.6.column_exists', 'p7.6.column_created')
    def test_col_exist(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['write_func']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Check condition
            assert 'comment_length' in locals()['df'].columns

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}The column "comment_length" was defined '
                                     f'successfully! 2 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'The column "comment_length" has not been defined. Did you assign the ' \
                     'output to the correct column in the DataFrame?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)

    @points('p7.6.function_applied', 'p7.6.function_works', 'p7.6.function_output',
            'p7.6.function_output_x2', 'p7.6.function_output_x3')
    def test_col_values(self):

        # Perform test
        try:

            # Run the previous exercise cell for preliminaries
            exec(nb.cells[exercises['import_pandas']].source)
            exec(nb.cells[exercises['read_csv']].source)
            exec(nb.cells[exercises['write_func']].source)

            # Run the cell within the function for local scope
            exec(self.cell.source)

            # Load the data
            test_df = pd.read_csv('data/gnm_comments_500.csv')
            test_df['comment_length'] = test_df['comment_text'].apply(lambda x: len(x.split()))

            # Check condition
            assert test_df['comment_length'].equals(locals()['df']['comment_length'])

            # Define message for passing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.OKGREEN}Applying the function "comm_len" to the '
                                     f'column "comment_text" returned the correct output! '
                                     f'5 points.{Colors.ENDC}'}

            # Set flag
            fail = False

        except AssertionError:

            # Define error message
            errmsg = 'Applying the function "comm_len" to the column "comment_text" did not ' \
                     'return the expected output. Did you apply the function to the correct ' \
                     'column in the DataFrame?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except NameError:

            # Define error message
            errmsg = 'Some variables remain undefined. Have you already ' \
                     'completed the previous exercises in this Notebook?'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        except UnboundLocalError:

            # Define error message
            errmsg = 'Your code raised an UnboundLocalError. Did you use a lambda function to ' \
                     'apply your function to the DataFrame? Remember that the apply() method ' \
                     'can also take a function as input.'

            # Define a message for failing the test
            message = {'text/plain': f'{Colors.BOLD}[TMC]{Colors.ENDC} '
                                     f'{Colors.FAIL}{errmsg}{Colors.ENDC}'}

            # Set flag
            fail = True

        # Write the result to the cell
        write_result(nb=nb,
                     nb_path=nb_path,
                     cell=self.cell,
                     output_type='execute_result',
                     data=message,
                     execution_count=self.cell.execution_count)

        # Check flag
        if fail:

            # Use the fail method to fail the test
            self.fail(errmsg)
